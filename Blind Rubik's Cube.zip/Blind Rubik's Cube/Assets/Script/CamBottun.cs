﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
using System.IO;
using System.Text;

public class CamBottun : MonoBehaviour
{
    public int trials = 0; 
    public int Surface = 0;

    [SerializeField]
    private Button _button = null;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Surface >= 6)
        {
            _button.interactable = false;
        }
    }

    public void CamClick()
    {
        string image = "Assets/ScreenShot/"+ trials.ToString() + "_" + Surface.ToString() + ".png";
        Debug.Log(image);
        //ScreenCapture.CaptureScreenshot(image);

        StartCoroutine(Capture(image));

        Surface++;
    }

    IEnumerator Capture(string image)
    {
        // ①
        yield return new WaitForEndOfFrame();

        // ②
        Vector2 size = new Vector2(325.0f, 325.0f); //可変
        Texture2D tex = new Texture2D((int)size.x,
                        (int)size.y,
                        TextureFormat.ARGB32,
                        false);

        // ③
        tex.ReadPixels(new Rect(502.0f, 215.0f, size.x, size.y), 0, 0);
        　　　　　　　　　　　//可変　　可変
        // ④
        tex.Apply();
        
        // ⑤
        //string image_path = "SS.png";
        byte[] pngdata = tex.EncodeToPNG();
        File.WriteAllBytes(image, pngdata);
    }
}
