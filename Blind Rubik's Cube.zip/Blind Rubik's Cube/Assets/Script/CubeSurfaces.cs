﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeSurfaces : MonoBehaviour
{
    /*[SerializeField]
    private Material red = null;

    [SerializeField]
    private Material[] cap = null; 
    */
    // Start is called before the first frame update
    [SerializeField]
    private MeshRenderer[] _sur = null;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void pasting(int _num)
    {
        //_sur[_num].material.SetInt = 1;
    }
}
